package dev.vlab.playlab

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
