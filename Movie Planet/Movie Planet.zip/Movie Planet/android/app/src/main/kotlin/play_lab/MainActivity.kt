package dev.vlab.play_lab
import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
