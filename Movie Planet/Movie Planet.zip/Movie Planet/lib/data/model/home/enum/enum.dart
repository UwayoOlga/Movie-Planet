enum LoadingEnum { all, featureMovieLoading, freeZoneMovieLoading, latestSeriesMovieLoading, liveTvLoading, recentMovieLoading, singleBannerImageLoading, trailerMovieLoading, sliderLoading }
