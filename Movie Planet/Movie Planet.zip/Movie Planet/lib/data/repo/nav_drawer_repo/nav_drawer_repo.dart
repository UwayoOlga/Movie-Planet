import 'package:play_lab/data/services/api_service.dart';

class NavDrawerRepo{
  ApiClient apiClient;
  NavDrawerRepo({required this.apiClient});
}